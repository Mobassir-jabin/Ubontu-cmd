read a
read b 
c=`expr $[a+b]`
printf "%f" $[c]
