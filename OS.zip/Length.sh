name="Rumi"

printf "Length: %d\n" ${#name}
