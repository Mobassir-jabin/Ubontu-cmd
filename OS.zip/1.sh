read -p "Enter a character to check vowel or consonant: " C


case "$C" in
 'A') echo "Vowel" 
  exit
  ;;
 'E') echo "Vowel" 
  exit 
  ;;
 'I') echo "Vowel" 
  exit
  ;;  
 'O') echo "Vowel" 
  exit
  ;;
 'U') echo "Vowel" 
  exit
  ;;
esac
echo "Consonant"
